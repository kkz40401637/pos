<?php $__env->startSection('title','Customer'); ?>
<?php $__env->startSection('food ','menu-open'); ?>
<?php $__env->startSection('food.active ','active'); ?>
<?php $__env->startSection('category','active'); ?>
<?php $__env->startSection('content'); ?>

    <food_category :token="{ value: '<?php echo e(csrf_token()); ?>'}"></food_category>
    
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swa/code/my_pos/resources/views/food/category.blade.php ENDPATH**/ ?>