<?php $__env->startSection('title','Customer'); ?>
<?php $__env->startSection('food ','menu-open'); ?>
<?php $__env->startSection('food.active ','active'); ?>
<?php $__env->startSection('product','active'); ?>
<?php $__env->startSection('content'); ?>

<food_product :category="<?php echo e($category); ?>"></food_product>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my_pos\resources\views/food/product.blade.php ENDPATH**/ ?>