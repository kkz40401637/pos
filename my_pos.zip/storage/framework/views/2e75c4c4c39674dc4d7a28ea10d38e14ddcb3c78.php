<?php $__env->startSection('title','Customer'); ?>
<?php $__env->startSection('customer','active'); ?>
<?php $__env->startSection('content'); ?>

    <customer :token="{ value: '<?php echo e(csrf_token()); ?>'}"></customer>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swa/code/my_pos/resources/views/customer.blade.php ENDPATH**/ ?>