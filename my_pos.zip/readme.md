## Database Structure

+users
	
	id,
	name,
	name_kh,
	gendre,
	dob,
	address,
	phone,
	hire_date,
	position,
	photo,
	email,
	password,
	…………

+Customer
	id,
	name,
	gender,
	phone,
	address,
+Table
	id,
	name,
	dsc,
	
+Category
	id,
	name,
	name_kh,
	dsc,
+Products
	id,
	name,
	name_kd,
	price,
	photo, 
	dsc,
	category => Categories,
	
